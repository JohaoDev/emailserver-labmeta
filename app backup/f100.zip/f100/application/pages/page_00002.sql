prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>1301688811807883
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'LABMETA'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(4421244819827293)
,p_name=>unistr('Envio Correo Electr\00F3nico')
,p_alias=>unistr('ENVIO-CORREO-ELECTR\00D3NICO')
,p_step_title=>unistr('Envio Correo Electr\00F3nico')
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.20.0/axios.min.js" integrity="sha512-quHCp3WbBNkwLfYUMd+KwBAgpVukJu5MncuQaWXgCrfgcxCJAq/fo+oqrRKOj+UKEmyMCG3tb8RB63W+EmrOBg==" crossorigin="anonymous"></script>',
'',
'<link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function sendEmail() {',
'    const url = "http://localhost:5000/send-email",',
'          emailBody = {',
'              data: {',
unistr('                  email: prompt("Ingrese su correo electr\00F3nico"),'),
'                  message: "Hello World"',
'              }',
'          };',
'    ',
'    axios.post(url, emailBody)',
'    .then(response => {',
'    response.data.ok ?',
'        alert("Correo enviado exitosamente") :',
'        alert("Algo salio mal");',
'    })',
'    .catch(err => {',
'        console.error(err);',
'    })',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'JOHAO'
,p_last_upd_yyyymmddhh24miss=>'20201001103735'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4435415223872701)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4336732801827134)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(4435850842872705)
,p_plug_name=>'README'
,p_parent_plug_id=>wwv_flow_api.id(4435415223872701)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_api.id(4336732801827134)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<body>',
'    <div class="pt-12 mx-32">',
'        <h1 class="text-center text-6xl">Readme</h1>',
'        <p class="pt-12">',
unistr('            Se desarrollo un servidor express al cual se implemento un m\00F3dulo de envio de correo electr\00F3nico llamado Nodemailer. <br><br>'),
'',
unistr('            Endpoint de conexi\00F3n: http://localhost:5000/send-email <br><br>'),
'',
'            <h1>Pasos para levantar servidor express.</h1>',
'            1. Descargar servidor del siguiente enlace:',
'',
'            https://github.com/vimhash/emailserver-labmeta <br><br>',
'',
'            2. Abrir una terminal en la carpeta emailserver-labmeta y escribimos: <br>',
'',
'            $ npm install <br><br>',
'',
unistr('            Esto har\00E1 que se instalen las dependencias necesarias para ejecutar el servidor. <br><br>'),
'',
'            3. Copiamos el archivo ".env example" y lo renombramos a ".env". <br><br>',
'',
'            4. Y llenamos las variables que se encuentran en el archivo. <br>',
'            ',
unistr('            EMAIL_USER = "correo electr\00F3nico" <br>'),
unistr('            EMAIL_PASS = "su clave de correo electr\00F3nico" <br><br>'),
'            ',
unistr('            5. Y por \00FAltimo en la terminal ejecutamos "npm start" y esperamos hasta que el servidor nos notifique que se encuentra funcionando.'),
'',
'        </p>',
'    </div>',
'</body>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(4435503695872702)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(4435415223872701)
,p_button_name=>'EnviarCorreoPrueba'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_api.id(4398997090827229)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar correo'
,p_button_position=>'REGION_TEMPLATE_PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-at'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(4435604178872703)
,p_name=>'SendEmail'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(4435503695872702)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(4435764015872704)
,p_event_id=>wwv_flow_api.id(4435604178872703)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'sendEmail()'
);
wwv_flow_api.component_end;
end;
/
